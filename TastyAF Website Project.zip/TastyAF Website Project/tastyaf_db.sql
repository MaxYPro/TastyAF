-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 02, 2025 at 06:21 PM
-- Server version: 8.0.43
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tastyaf_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `bookings`
--

CREATE TABLE `bookings` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `basket_items` text NOT NULL,
  `total` decimal(10,2) NOT NULL,
  `status` enum('pending','confirmed','completed','cancelled') NOT NULL DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `bookings`
--

INSERT INTO `bookings` (`id`, `user_id`, `full_name`, `phone`, `basket_items`, `total`, `status`, `created_at`, `updated_at`) VALUES
(1, 1, 'asdsa', 'asdsad', '[{\"name\":\"Chicken Shawarma\",\"price\":\"£8.50\",\"toppings\":[\"🧄 Garlic\",\"🍅 Ketchup\"]},{\"name\":\"Mix Shawarma\",\"price\":\"£9.00\",\"toppings\":[]}]', 0.00, 'cancelled', '2025-10-02 00:07:22', '2025-10-02 00:47:27'),
(2, 2, 'Admin', '0352325325', '[{\"name\":\"Pork Shawarma\",\"price\":\"£9.50\",\"toppings\":[]},{\"name\":\"Chicken Shawarma\",\"price\":\"£8.50\",\"toppings\":[\"🧄 Garlic\",\"🍅 Ketchup\",\"🌶 Chili Sauce\"]},{\"name\":\"Pork Shawarma\",\"price\":\"£9.50\",\"toppings\":[\"🥓 BBQ Sauce\"]},{\"name\":\"Mix Shawarma\",\"price\":\"£9.00\",\"toppings\":[]}]', 0.00, 'completed', '2025-10-02 00:28:02', '2025-10-02 00:36:47'),
(3, 2, 'asda', 'sadsa', '[{\"name\":\"Chicken Shawarma\",\"price\":\"£8.50\",\"toppings\":[\"🧄 Garlic\"]}]', 0.00, 'completed', '2025-10-02 00:34:59', '2025-10-02 00:46:55'),
(4, 2, 'sadsa', 'sadsa', '[{\"name\":\"Chicken Shawarma\",\"price\":\"£8.50\",\"toppings\":[\"🍅 Ketchup\"]}]', 0.00, 'cancelled', '2025-10-02 00:48:22', '2025-10-02 00:48:26'),
(5, 2, 'dd', 'dd', '[{\"name\":\"Pork Shawarma\",\"price\":\"£9.50\",\"toppings\":[\"🥓 BBQ Sauce\"]}]', 0.00, 'cancelled', '2025-10-02 00:49:10', '2025-10-02 16:01:50'),
(6, 1, 'Maxim Pereu', '03243243434', '[{\"name\":\"Chicken Shawarma\",\"price\":\"£8.50\",\"toppings\":[\"🧄 Garlic\",\"🍅 Ketchup\"]}]', 0.00, 'completed', '2025-10-02 16:01:14', '2025-10-02 16:01:47'),
(7, 1, 'Maxim Pereu', '32432432432', '[{\"name\":\"Chicken Shawarma\",\"price\":\"£8.50\",\"toppings\":[\"🧄 Garlic\"]},{\"name\":\"Mix Shawarma\",\"price\":\"£9.00\",\"toppings\":[]}]', 0.00, 'completed', '2025-10-02 16:05:58', '2025-10-02 16:06:18');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('user','admin') NOT NULL DEFAULT 'user'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `role`) VALUES
(1, 'Maxim', 'maxim@gmail.com', '$2y$10$swK88M7seDq9S2fnb2YJNuenKQ4tu4SUpoiY26gdWNOzlm3nHmY46', 'user'),
(2, 'Admin', 'admin@gmail.com', '$2y$10$63O6P08ox3MKLkyvC6wI.ec3CtrqLcp/fwdh3lW/vINop0qG0fbzW', 'admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bookings`
--
ALTER TABLE `bookings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bookings`
--
ALTER TABLE `bookings`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `bookings`
--
ALTER TABLE `bookings`
  ADD CONSTRAINT `bookings_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
