<?php
session_start();
require_once __DIR__ . "/db.php";

header("Content-Type: application/json");

try {
    if (!isset($_SESSION['username'])) {
        echo json_encode(["success" => false, "message" => "User not logged in."]);
        exit;
    }

    $fullName = $_POST['fullName'] ?? '';
    $phone    = $_POST['phone'] ?? '';
    $basket   = $_POST['basket'] ?? '[]';
    $total    = $_POST['total'] ?? 0;

    $username = $_SESSION['username'];

    $stmt = $conn->prepare("SELECT id FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->bind_result($userId);
    $stmt->fetch();
    $stmt->close();

    if (!$userId) {
        echo json_encode(["success" => false, "message" => "User not found."]);
        exit;
    }

    $stmt = $conn->prepare("
        INSERT INTO bookings (user_id, full_name, phone, basket_items, total, status, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, 'pending', NOW(), NOW())
    ");
    $stmt->bind_param("isssd", $userId, $fullName, $phone, $basket, $total);

    if ($stmt->execute()) {
        echo json_encode(["success" => true, "message" => "Booking saved successfully."]);
    } else {
        echo json_encode(["success" => false, "message" => "Database error: " . $stmt->error]);
    }

    $stmt->close();

} catch (Exception $e) {
    echo json_encode(["success" => false, "message" => $e->getMessage()]);
}
