<?php
$host = "localhost";
$db   = "tastyaf_db";
$user = "root";
$pass = "root123";

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}
