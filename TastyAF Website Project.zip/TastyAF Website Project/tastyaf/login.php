<?php
session_start();
include 'php/db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT id, username, password, role FROM users WHERE username=? OR email=? LIMIT 1");
    $stmt->bind_param("ss", $username, $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($row = $result->fetch_assoc()) {
        if (password_verify($password, $row['password'])) {
            session_regenerate_id(true);

            $_SESSION['user_id']  = $row['id'];
            $_SESSION['username'] = $row['username'];
            $_SESSION['role']     = $row['role'];

            $stmt->close();
            header("Location: index.php");
            exit();
        } else {
            $_SESSION['error'] = "Username or password is incorrect";
            header("Location: login.php");
            exit();
        }
    } else {
        $_SESSION['error'] = "Username or password is incorrect";
        header("Location: login.php");
        exit();
    }

    $stmt->close();
}
?>


<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="img/logo.png" />
    <title>TastyAF - Login</title>
    <link rel="stylesheet" href="css/account.css">
    <script src="https://kit.fontawesome.com/e37f0e4748.js" crossorigin="anonymous"></script>
</head>
<body>
    <div class="form-container">
        <a href="index.php">
            <img src="img/logo.png" alt="CETS Logo" class="form-logo">
        </a>

        <form method="POST">
            <h2>Login</h2>

            <?php if (!empty($_SESSION['error'])): ?>
                <div class="error-message"><?php echo $_SESSION['error']; ?></div>
                <?php unset($_SESSION['error']); ?>
            <?php endif; ?>

            <input type="text" name="username" placeholder="Username or Email" required><br>
            <input type="password" name="password" placeholder="Password" required><br>
            <button type="submit">Login</button>

            <div class="switch-form">
                <p>Don’t have an account?</p>
                <a href="register.php" class="btn-link">Register</a>
            </div>
        </form>
    </div>
</body>
</html>
