<nav>
    <div class="logo">
        <a href="index.php">
            <img class="logonav" src="img/logo.png" alt="TastyAF Logo">
        </a>
    </div>

    <ul>
        <li><a href="index.php">Home</a></li>
        <?php if (isset($_SESSION['username'])): ?>
            <div class="hamburger" id="hamburger">
                <i class="fa-solid fa-bars"></i>
            </div>
        <li class="nav-profile">
            <div class="profile-toggle">
                <i class="usericon fa-solid fa-user"></i>
                <?php echo htmlspecialchars($_SESSION['username']); ?> ▾
            </div>
            <ul class="profile-dropdown">
                <li><a href="profile.php">Profile</a></li>
                <li><a href="php/logout.php">Logout</a></li>
            </ul>
        </li>
        <?php else: ?>
        <li><a href="login.php" class="btn-login">Login</a></li>
        <?php endif; ?>
        <?php if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin'): ?>
        <li><a href="admin.php" class="btn-login">Admin Panel</a></li>
        <?php endif; ?>
        </li>
    </ul>
</nav>


<script>
    (function () {
        const hamburger = document.getElementById('hamburger');
        const navLinks = document.getElementById('nav-links');

        if (!hamburger || !navLinks) return;

        function toggleMenu() {
            const open = navLinks.classList.toggle('active');
            hamburger.setAttribute('aria-expanded', open ? 'true' : 'false');
            hamburger.innerHTML = open
                ? '<i class="fa-solid fa-xmark"></i>'
                : '<i class="fa-solid fa-bars"></i>';
        }

        hamburger.addEventListener('click', toggleMenu);

        navLinks.addEventListener('click', (e) => {
            if (e.target.tagName === 'A') {
                navLinks.classList.remove('active');
                hamburger.setAttribute('aria-expanded', 'false');
                hamburger.innerHTML = '<i class="fa-solid fa-bars"></i>';
            }
        });
    })();
</script>