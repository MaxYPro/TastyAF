<?php
session_start();
include 'php/db.php';

if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}

$q = $conn->prepare("
    SELECT b.id, u.username, b.full_name, b.phone, b.basket_items, b.total, b.status, b.created_at
    FROM bookings b
    JOIN users u ON b.user_id = u.id
    ORDER BY b.created_at DESC
");
$q->execute();
$orders = $q->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>

  <meta charset="UTF-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <link rel="shortcut icon" href="img/logo.png" />
  <title>TastyAF - Admin Panel</title>
  <script src="https://kit.fontawesome.com/e37f0e4748.js" crossorigin="anonymous"></script>
  <meta charset="UTF-8">
  <title>Admin Panel - Manage Orders</title>
  <link rel="stylesheet" href="css/style.css">
  <style>
    .admin-container {
      max-width: 1100px;
      margin: 120px auto;
      padding: 30px;
      background: #111;
      border-radius: 15px;
      color: #fff;
      box-shadow: 0 8px 25px rgba(0,0,0,0.6);
    }
    .admin-container h2 {
      margin-bottom: 25px;
      font-size: 26px;
      color: #ff3c3c;
      display: flex;
      align-items: center;
      gap: 10px;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 15px;
    }
    th, td {
      padding: 12px 15px;
      text-align: left;
    }
    th {
      background: #1c1c1c;
      color: #ff3c3c;
      text-transform: uppercase;
      font-size: 13px;
      border-bottom: 2px solid #333;
    }
    tr:nth-child(even) {
      background: #1a1a1a;
    }
    tr:nth-child(odd) {
      background: #151515;
    }

    .btn-accept {
      background: #ffc107;
      border: none;
      padding: 6px 12px;
      border-radius: 6px;
      cursor: pointer;
      color: #000;
      font-weight: bold;
    }
    .btn-accept:hover { background: #e0a800; }

    .btn-complete {
      background: #28a745;
      border: none;
      padding: 6px 12px;
      border-radius: 6px;
      cursor: pointer;
      color: #fff;
      font-weight: bold;
    }
    .btn-complete:hover { background: #218838; }

    .btn-cancel {
      background: #dc3545;
      border: none;
      padding: 6px 12px;
      border-radius: 6px;
      cursor: pointer;
      color: #fff;
      font-weight: bold;
    }
    .btn-cancel:hover { background: #c82333; }

    .status-badge {
      padding: 5px 12px;
      border-radius: 8px;
      font-weight: bold;
      display: inline-block;
    }
    .status-badge.pending { background: #ffc107; color: #000; }
    .status-badge.confirmed { background: #17a2b8; color: #fff; }
    .status-badge.completed { background: #28a745; color: #fff; }
    .status-badge.cancelled { background: #dc3545; color: #fff; }

    ul.item-list {
      margin: 0;
      padding-left: 18px;
    }
    ul.item-list li { margin: 3px 0; }
  </style>
</head>
<body>
<?php include 'nav.php'; ?>

<div class="admin-container">
  <h2>📋 Manage Orders</h2>

  <table>
    <tr>
      <th>ID</th>
      <th>User</th>
      <th>Name</th>
      <th>Phone</th>
      <th>Items</th>
      <th>Total (£)</th>
      <th>Status</th>
      <th>Ordered At</th>
      <th>Action</th>
    </tr>
    <?php while ($row = $orders->fetch_assoc()) {
        $status = strtolower($row['status']);
        $items = json_decode($row['basket_items'], true);
    ?>
      <tr>
        <td><?php echo $row['id']; ?></td>
        <td><?php echo htmlspecialchars($row['username']); ?></td>
        <td><?php echo htmlspecialchars($row['full_name']); ?></td>
        <td><?php echo htmlspecialchars($row['phone']); ?></td>
        <td>
          <ul class="item-list">
            <?php if (!empty($items)) {
              foreach ($items as $item) {
                echo "<li>" . htmlspecialchars($item['name']);
                if (!empty($item['toppings'])) {
                  echo " (" . implode(", ", array_map("htmlspecialchars", $item['toppings'])) . ")";
                }
                echo "</li>";
              }
            } ?>
          </ul>
        </td>
        <td><?php echo number_format($row['total'], 2); ?></td>
        <td>
          <?php if ($status === 'pending') { ?>
            <span class="status-badge pending">Pending</span>
          <?php } elseif ($status === 'confirmed') { ?>
            <span class="status-badge confirmed">Confirmed</span>
          <?php } elseif ($status === 'completed') { ?>
            <span class="status-badge completed">Completed</span>
          <?php } elseif ($status === 'cancelled') { ?>
            <span class="status-badge cancelled">Cancelled</span>
          <?php } ?>
        </td>
        <td><?php echo date("d M Y H:i", strtotime($row['created_at'])); ?></td>
        <td>
          <?php if ($status === 'pending') { ?>
            <form method="POST" action="php/update_status.php" style="display:inline;">
              <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
              <input type="hidden" name="status" value="confirmed">
              <button type="submit" class="btn-accept">Accept</button>
            </form>
            <form method="POST" action="php/update_status.php" style="display:inline;">
              <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
              <input type="hidden" name="status" value="cancelled">
              <button type="submit" class="btn-cancel">Cancel</button>
            </form>
          <?php } elseif ($status === 'confirmed') { ?>
            <form method="POST" action="php/update_status.php" style="display:inline;">
              <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
              <input type="hidden" name="status" value="completed">
              <button type="submit" class="btn-complete">Complete</button>
            </form>
            <form method="POST" action="php/update_status.php" style="display:inline;">
              <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
              <input type="hidden" name="status" value="cancelled">
              <button type="submit" class="btn-cancel">Cancel</button>
            </form>
          <?php } ?>
        </td>
      </tr>
    <?php } ?>
  </table>
</div>
</body>
</html>
