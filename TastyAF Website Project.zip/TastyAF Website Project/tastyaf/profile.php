<?php
session_start();
include 'php/db.php';

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

$user = $_SESSION['username'];

$u = $conn->prepare("SELECT id FROM users WHERE username=?");
$u->bind_param("s", $user);
$u->execute();
$userData = $u->get_result()->fetch_assoc();
$user_id = $userData['id'];

$b = $conn->prepare("
    SELECT id, full_name, phone, basket_items, total, status, created_at 
    FROM bookings 
    WHERE user_id = ? 
    ORDER BY created_at DESC
");
$b->bind_param("i", $user_id);
$b->execute();
$bookings = $b->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <link rel="shortcut icon" href="img/logo.png" />
  <title>TastyAF - Profile</title>
    <link rel="stylesheet" href="css/style.css" />
  <link rel="stylesheet" href="css/profile.css" />
  <script src="https://kit.fontawesome.com/e37f0e4748.js" crossorigin="anonymous"></script>
</head>
<body>
    <?php include 'nav.php'; ?>

    <div class="profile-container">
        <h2>👤 <?php echo htmlspecialchars($user); ?>'s Profile</h2>

        <h3>🧾 My Orders</h3>
        <?php if ($bookings->num_rows > 0) { ?>
            <table class="profile-table">
                <tr>
                    <th>Name</th>
                    <th>Phone</th>
                    <th>Items</th>
                    <th>Total (£)</th>
                    <th>Status</th>
                    <th>Ordered At</th>
                </tr>
                <?php while ($row = $bookings->fetch_assoc()) { ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['full_name']); ?></td>
                        <td><?php echo htmlspecialchars($row['phone']); ?></td>
                        <td>
                          <?php
                          $items = json_decode($row['basket_items'], true);
                          if (is_array($items)) {
                              foreach ($items as $item) {
                                  echo "• " . htmlspecialchars($item['name']);
                                  if (!empty($item['toppings'])) {
                                      echo " <small>(" . htmlspecialchars(implode(", ", $item['toppings'])) . ")</small>";
                                  }
                                  echo "<br>";
                              }
                          } else {
                              echo htmlspecialchars($row['basket_items']);
                          }
                          ?>
                        </td>
                        <td><?php echo number_format($row['total'], 2); ?></td>
                        <td>
                          <span class="status-<?php echo $row['status']; ?>">
                            <?php echo ucfirst($row['status']); ?>
                          </span>
                        </td>
                        <td><?php echo date("d M Y H:i", strtotime($row['created_at'])); ?></td>
                    </tr>
                <?php } ?>
            </table>
        <?php } else { ?>
            <div class="empty-state">
                <i class="fa-solid fa-receipt"></i> No orders yet.
            </div>
        <?php } ?>
    </div>
</body>
</html>
