<?php
session_start();
?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="shortcut icon" href="img/logo.png" />
    <title>TastyAF - Order Online</title>
    <link rel="stylesheet" href="css/style.css" />
    <script src="https://kit.fontawesome.com/e37f0e4748.js" crossorigin="anonymous"></script>
</head>
<script type="text/javascript" src="https://sandbox.web.squarecdn.com/v1/square.js"></script>

<body>

    <body <?php if (isset($_SESSION['username'])) echo 'data-loggedin="true"' ; else echo 'data-loggedin="false"' ; ?>>

        <nav>
            <div class="logo">
                <a href="index.php">
                    <img class="logonav" src="img/logo.png" alt="TastyAF Logo">
                </a>
            </div>

            <div class="hamburger" id="hamburger">
                <i class="fa-solid fa-bars"></i>
            </div>

            <ul id="nav-links">
                <li><a href="#home">Home</a></li>
                <li><a href="#menu">Menu</a></li>
                <li><a href="#about">About Us</a></li>
                <li><a href="#contact">Contact</a></li>

                <?php if (isset($_SESSION['username'])): ?>
                <li class="nav-profile">
                    <div class="profile-toggle">
                        <i class="usericon fa-solid fa-user"></i>
                        <?php echo htmlspecialchars($_SESSION['username']); ?> ▾
                    </div>
                    <ul class="profile-dropdown">
                        <li><a href="profile.php">Profile</a></li>
                        <li><a href="php/logout.php">Logout</a></li>
                    </ul>
                </li>
                <?php else: ?>
                <li><a href="login.php" class="btn-login">Login</a></li>
                <?php endif; ?>

                <?php if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin'): ?>
                <li><a href="admin.php" class="btn-login">Admin Panel</a></li>
                <?php endif; ?>

                <li class="nav-basket">
                    <a href="#" id="basketBtn">
                        <i class="fa-solid fa-basket-shopping"></i> <span id="basketCount">0</span>
                    </a>
                    <div id="basketDropdown" class="basket-dropdown">
                        <h3>Your Basket</h3>
                        <ul id="basketItems"></ul>
                        <div class="basket-actions">
                            <button id="checkoutBtn">Checkout</button>
                            <button id="clearBasketBtn">Clear</button>
                        </div>
                    </div>
                </li>
            </ul>
        </nav>



        <section id="home" class="hero">
            <div class="hero-content">
                <h1>TastyAF<br>Food Trailer</h1>
                <p>
                    Taste the difference with our freshly made shawarmas —
                    packed with flavor, made with passion.
                </p>

                <div class="cta-buttons">
                    <a href="register.php" class="btn btn-primary">Join Us</a>
                    <button class="btn btn-secondary" id="viewMenuBtn">View Menu</button>
                </div>

            </div>
            <div class="hero-image">
                <div class="burger-showcase">
                    <div class="floating-element tomato"></div>
                    <div class="floating-element chili"></div>
                    <div class="menu-card-image" style="width: 100%; height: 100%;">
                        <img class="logomain" src="img/logo.png">
                    </div>
                </div>
            </div>
        </section>




        <div id="toppingsModal" class="modal">
            <div class="modal-content">
                <span class="close-modal">&times;</span>

                <div class="modal-header">
                    <img id="modalItemImage" src="" alt="Item Image">
                    <div class="modal-header-info">
                        <h2 id="modalItemName">Item Name</h2>
                        <p id="modalItemDescription">Item description goes here.</p>
                        <span class="modal-price" id="modalItemPrice">£0.00</span>
                    </div>
                </div>

                <h3>Choose Toppings</h3>
                <form id="toppingsForm" class="toppings-list">
                    <label class="topping-option">
                        <input type="checkbox" name="toppings" value="Garlic">
                        <span>🧄 Garlic</span>
                    </label>

                    <label class="topping-option">
                        <input type="checkbox" name="toppings" value="Ketchup">
                        <span>🍅 Ketchup</span>
                    </label>

                    <label class="topping-option">
                        <input type="checkbox" name="toppings" value="Extra Cheese">
                        <span>🧀 Extra Cheese</span>
                    </label>

                    <label class="topping-option">
                        <input type="checkbox" name="toppings" value="Chili Sauce">
                        <span>🌶 Chili Sauce</span>
                    </label>
                </form>


                <div class="modal-actions">
                    <button type="button" id="cancelToppings">Cancel</button>
                    <button type="button" id="addToBasket">Add to Basket</button>
                </div>
            </div>
        </div>


        <div id="checkoutModal" class="modal">
            <div class="modal-content">
                <span class="close-modal"
                    onclick="document.getElementById('checkoutModal').style.display='none'">&times;</span>
                <h2>Checkout</h2>

                <form id="checkoutForm" onsubmit="return false;">
                    <div class="form-group">
                        <label for="fullName">Full Name</label>
                        <input type="text" id="fullName" name="fullName" required>
                    </div>

                    <div class="form-group">
                        <label for="phone">Phone Number</label>
                        <input type="text" id="phone" name="phone" required>
                    </div>

                    <div class="collection-info">
                        <h3>📍 Collection Address</h3>
                        <p>TastyAF<br>
                            25-26 Ross Rd<br>
                            Northampton NN5 5AX</p>
                        <p><strong>Opening Hours:</strong> 11:00 - 23:00</p>
                    </div>

                    <div class="modal-actions">
                        <div id="card-container"></div>
                        <button id="card-button" type="button" class="btn-primary">Confirm & Pay</button>

                    </div>
                </form>
            </div>
        </div>





        <section id="menu" class="menu-section">
            <h2 class="section-title">MENU</h2>

            <div class="menu-filters">
                <button class="filter-btn active" data-category="all">All</button>
                <button class="filter-btn" data-category="shawarma">Shawarma</button>
                <button class="filter-btn" data-category="burgers">Burgers</button>
                <button class="filter-btn" data-category="sides">Sides</button>
                <button class="filter-btn" data-category="drinks">Drinks</button>
            </div>




            <div class="menu-grid">
                <div class="menu-card" data-category="shawarma" data-item="chicken-shawarma">
                    <div class="menu-card-image">
                        <img class="foodimg" src="img/food/1.jpg">
                    </div>
                    <h3>Chicken Shawarma</h3>
                    <p class="menu-card-description">Juicy grilled chicken, wrapped fresh.</p>
                    <div class="menu-card-footer">
                        <span class="price">£8.50</span>
                        <button class="add-btn">+</button>
                    </div>
                </div>

                <div class="menu-card" data-category="shawarma" data-item="pork-shawarma">
                    <div class="menu-card-image">
                        <img class="foodimg" src="img/logo.png">
                    </div>
                    <h3>Pork Shawarma</h3>
                    <p class="menu-card-description">Tender pork, slow cooked on the spit.</p>
                    <div class="menu-card-footer">
                        <span class="price">£9.50</span>
                        <button class="add-btn">+</button>
                    </div>
                </div>

                <div class="menu-card" data-category="shawarma" data-item="mix-shawarma">
                    <div class="menu-card-image">
                        <img class="foodimg" src="img/logo.png">
                    </div>
                    <h3>Mix Shawarma</h3>
                    <p class="menu-card-description">Best of both chicken & pork.</p>
                    <div class="menu-card-footer">
                        <span class="price">£9.00</span>
                        <button class="add-btn">+</button>
                    </div>
                </div>

                <div class="menu-card" data-category="burgers" data-item="chicken-burger">
                    <div class="menu-card-image">
                        <img class="foodimg" src="img/logo.png">
                    </div>
                    <h3>Chicken Burger</h3>
                    <p class="menu-card-description">Crispy chicken fillet in a soft bun.</p>
                    <div class="menu-card-footer">
                        <span class="price">£6.50</span>
                        <button class="add-btn">+</button>
                    </div>
                </div>

                <div class="menu-card" data-category="burgers" data-item="beef-burger">
                    <div class="menu-card-image">
                        <img class="foodimg" src="img/logo.png">
                    </div>
                    <h3>Beef Burger</h3>
                    <p class="menu-card-description">Classic single beef patty, flame grilled.</p>
                    <div class="menu-card-footer">
                        <span class="price">£7.50</span>
                        <button class="add-btn">+</button>
                    </div>
                </div>

                <div class="menu-card" data-category="burgers" data-item="double-beef-burger">
                    <div class="menu-card-image">
                        <img class="foodimg" src="img/logo.png">
                    </div>
                    <h3>Double Beef Burger</h3>
                    <p class="menu-card-description">Two juicy patties for double flavor.</p>
                    <div class="menu-card-footer">
                        <span class="price">£8.50</span>
                        <button class="add-btn">+</button>
                    </div>
                </div>

                <div class="menu-card" data-category="burgers" data-item="triple-threat-burger">
                    <div class="menu-card-image">
                        <img class="foodimg" src="img/logo.png">
                    </div>
                    <h3>The Triple Threat Burger</h3>
                    <p class="menu-card-description">Triple stacked patties, pure indulgence.</p>
                    <div class="menu-card-footer">
                        <span class="price">£10.50</span>
                        <button class="add-btn">+</button>
                    </div>
                </div>

                <div class="menu-card" data-category="sides" data-item="chicken-wings">
                    <div class="menu-card-image">
                        <img class="foodimg" src="img/logo.png">
                    </div>
                    <h3>Chicken Wings</h3>
                    <p class="menu-card-description">Crispy, golden and finger-licking good.</p>
                    <div class="menu-card-footer">
                        <span class="price">£5.50</span>
                        <button class="add-btn">+</button>
                    </div>
                </div>

                <div class="menu-card" data-category="sides" data-item="chicken-nuggets">
                    <div class="menu-card-image">
                        <img class="foodimg" src="img/logo.png">
                    </div>
                    <h3>Chicken Nuggets</h3>
                    <p class="menu-card-description">Golden fried bites loved by everyone.</p>
                    <div class="menu-card-footer">
                        <span class="price">£4.50</span>
                        <button class="add-btn">+</button>
                    </div>
                </div>

                <div class="menu-card" data-category="sides" data-item="onion-rings">
                    <div class="menu-card-image">
                        <img class="foodimg" src="img/logo.png">
                    </div>
                    <h3>Onion Rings</h3>
                    <p class="menu-card-description">Crispy rings, crunchy and sweet.</p>
                    <div class="menu-card-footer">
                        <span class="price">£3.50</span>
                        <button class="add-btn">+</button>
                    </div>
                </div>

                <div class="menu-card" data-category="sides" data-item="chips">
                    <div class="menu-card-image">
                        <img class="foodimg" src="img/logo.png">
                    </div>
                    <h3>Chips</h3>
                    <p class="menu-card-description">Golden fries, hot and salty.</p>
                    <div class="menu-card-footer">
                        <span class="price">£2.50</span>
                        <button class="add-btn">+</button>
                    </div>
                </div>

                <div class="menu-card" data-category="drinks" data-item="coca-cola">
                    <div class="menu-card-image">
                        <img class="foodimg" src="img/logo.png">
                    </div>
                    <h3>Coca-Cola 330ml</h3>
                    <p class="menu-card-description">Refreshing and fizzy classic cola.</p>
                    <div class="menu-card-footer">
                        <span class="price">£1.50</span>
                        <button class="add-btn">+</button>
                    </div>
                </div>

                <div class="menu-card" data-category="drinks" data-item="fanta">
                    <div class="menu-card-image">
                        <img class="foodimg" src="img/logo.png">
                    </div>
                    <h3>Fanta 330ml</h3>
                    <p class="menu-card-description">Fruity and sparkling orange soda.</p>
                    <div class="menu-card-footer">
                        <span class="price">£1.50</span>
                        <button class="add-btn">+</button>
                    </div>
                </div>

                <div class="menu-card" data-category="drinks" data-item="sprite">
                    <div class="menu-card-image">
                        <img class="foodimg" src="img/logo.png">
                    </div>
                    <h3>Sprite 330ml</h3>
                    <p class="menu-card-description">Crisp lemon-lime sparkling drink.</p>
                    <div class="menu-card-footer">
                        <span class="price">£1.50</span>
                        <button class="add-btn">+</button>
                    </div>
                </div>
            </div>


        </section>

        <section id="features" class="features">
            <div class="features-content">
                <div class="features-text">
                    <h2>Juicy, Tender & Flavorful<br><span>Meat You’ll Love</span></h2>

                    <div class="feature-item">
                        <div class="feature-icon">🔥</div>
                        <div class="feature-text">
                            <h3>Perfectly Grilled</h3>
                            <p>Our shawarma is slow-cooked over open flame for unbeatable flavor.</p>
                        </div>
                    </div>

                    <div class="feature-item">
                        <div class="feature-icon">🥩</div>
                        <div class="feature-text">
                            <h3>Premium Cuts</h3>
                            <p>We only use high-quality meat, marinated with authentic spices.</p>
                        </div>
                    </div>

                    <div class="feature-item">
                        <div class="feature-icon">🍴</div>
                        <div class="feature-text">
                            <h3>Made Fresh</h3>
                            <p>Cooked on the spot and served hot, straight from the grill.</p>
                        </div>
                    </div>
                </div>

                <div class="features-image">
                    <img src="img/2.jpg" alt="Grilled Meat" class="salad-img">
                </div>
            </div>
        </section>



        <section id="about" class="about-section">
            <div class="about-content">
                <div class="about-image">
                    <div class="about-image-wrapper">
                        <img src="img/3.jpg" alt="TastyAF Shawarma" class="about-img">
                    </div>
                </div>
                <div class="about-text">
                    <h2>About Us</h2>
                    <p>
                        At <strong>TastyAF</strong>, we’re all about bringing bold flavors to the street.
                        From our sizzling shawarmas cooked over open flame to our signature UFO shed burgers,
                        every bite is made to satisfy.
                    </p>
                    <p>
                        We believe good food should be fresh, juicy, and unforgettable.
                        That’s why we use only premium cuts of meat, authentic spices, and
                        freshly sourced ingredients — served hot and packed with flavor.
                    </p>

                    <div class="about-stats">
                        <div class="stat-item">
                            <div class="stat-number">15+</div>
                            <div class="stat-label">Signature Dishes</div>
                        </div>
                        <div class="stat-item">
                            <div class="stat-number">2000+</div>
                            <div class="stat-label">Happy Foodies</div>
                        </div>
                        <div class="stat-item">
                            <div class="stat-number">🔥</div>
                            <div class="stat-label">Fresh Off the Grill</div>
                        </div>
                    </div>
                </div>
            </div>
        </section>


        <section id="contact" class="contact-section">
            <div class="contact-container">
                <h2 class="section-title">Contact Us</h2>

                <div class="contact-content">
                    <div class="contact-info">
                        <div class="contact-item">
                            <div class="contact-icon">📍</div>
                            <div class="contact-details">
                                <h3>Location</h3>
                                <p>25-26 Ross Rd, NN5 5AX<br>Northampton, UK</p>
                            </div>
                        </div>

                        <div class="contact-item">
                            <div class="contact-icon">📞</div>
                            <div class="contact-details">
                                <h3>Phone</h3>
                                <p>+44 7395109942</p>
                            </div>
                        </div>

                        <div class="contact-item">
                            <div class="contact-icon">✉️</div>
                            <div class="contact-details">
                                <h3>Email</h3>
                                <p>contact@tastyaf.com</p>
                            </div>
                        </div>
                    </div>

                    <form class="contact-form">
                        <div class="form-group">
                            <label for="name">Your Name</label>
                            <input type="text" id="name" placeholder="Enter your name" required>
                        </div>
                        <div class="form-group">
                            <label for="email">Your Email</label>
                            <input type="email" id="email" placeholder="Enter your email" required>
                        </div>
                        <div class="form-group">
                            <label for="message">Message</label>
                            <textarea id="message" placeholder="Write your message" required></textarea>
                        </div>
                        <button type="submit" class="submit-btn">Send Message</button>
                    </form>
                </div>

                <div class="map-container">
                    <div style="position: relative; width: 100%; height: 400px; border-radius: 15px; overflow: hidden;">
                        <iframe
                            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2461.272028262824!2d-0.9298907842254186!3d52.2408769797601!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4877070fbaaeed6d%3A0x7cf1acbcae8c6f9e!2s25-26%20Ross%20Rd%2C%20Northampton%20NN5%205AX!5e0!3m2!1sen!2suk!4v1735730000000!5m2!1sen!2suk"
                            width="100%" height="400" style="border:0;" allowfullscreen="" loading="lazy">
                        </iframe>
                        <div style="position:absolute; top:0; left:0; width:100%; height:100%; 
              background: linear-gradient(rgba(0,0,0,0.4), rgba(255, 136, 0, 0.37)); 
              pointer-events:none; border-radius:15px;"></div>
                    </div>

                </div>

        </section>

        <footer class="footer">
            <div class="footer-container">
                <div class="footer-section">
                    <img src="img/logo.png" alt="TastyAF Logo" class="footer-logo">
                    <p>
                        Serving the best shawarmas, burgers, and sides in Northampton.
                        Fresh, tasty, and made with passion.
                    </p>
                </div>

                <div class="footer-section">
                    <h3>Quick Links</h3>
                    <ul>
                        <li><a href="#home">Home</a></li>
                        <li><a href="#menu">Menu</a></li>
                        <li><a href="#about">About</a></li>
                        <li><a href="#contact">Contact</a></li>
                    </ul>
                </div>

                <div class="footer-section">
                    <h3>Contact</h3>
                    <p>📍 25-26 Ross Rd, Northampton NN5 5AX</p>
                    <p>📞 +44 123 456 789</p>
                    <p>✉️ info@tastyaf.com</p>
                </div>

                <div class="footer-section">
                    <h3>Follow Us</h3>
                    <div class="social-icons">
                        <a href="#"><i class="fab fa-facebook"></i></a>
                        <a href="#"><i class="fab fa-instagram"></i></a>
                        <a href="#"><i class="fab fa-twitter"></i></a>
                    </div>
                </div>
            </div>

            <div class="footer-bottom">
                <p>© 2025 TastyAF. All Rights Reserved.</p>
            </div>
        </footer>



        <script>

            document.querySelectorAll('a[href^="#"]').forEach(anchor => {
                anchor.addEventListener('click', function (e) {
                    e.preventDefault();

                    const targetId = this.getAttribute('href');
                    if (targetId !== "#" && targetId.startsWith("#")) {
                        const target = document.querySelector(targetId);
                        if (target) {
                            target.scrollIntoView({ behavior: 'smooth', block: 'start' });
                        }
                    }
                });
            });

            const addBtns = document.querySelectorAll('.add-btn');
            addBtns.forEach(btn => {
                btn.addEventListener('click', function () {
                    this.style.transform = 'rotate(90deg) scale(1.3)';
                    setTimeout(() => {
                        this.style.transform = 'rotate(0deg) scale(1)';
                    }, 300);
                });
            });
        </script>

        <script>
            const sections = document.querySelectorAll("section");
            const navLinks = document.querySelectorAll("nav ul li a");

            const options = {
                threshold: 0.6 
            };

            const observer = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        navLinks.forEach(link => link.classList.remove("active"));

                        const activeLink = document.querySelector(`nav ul li a[href="#${entry.target.id}"]`);
                        if (activeLink) activeLink.classList.add("active");
                    }
                });
            }, options);

            sections.forEach(section => {
                observer.observe(section);
            });
        </script>

        <script>
            document.getElementById("viewMenuBtn").addEventListener("click", () => {
                document.querySelector("#menu").scrollIntoView({
                    behavior: "smooth",
                    block: "start"
                });
            });
        </script>

        <script>
            (() => {
                const btns = document.querySelectorAll('.menu-filters .filter-btn');
                const cards = document.querySelectorAll('.menu-grid .menu-card');

                function applyFilter(cat) {
                    cards.forEach(card => {
                        if (cat === "all" || card.dataset.category === cat) {
                            card.style.removeProperty('display'); 
                        } else {
                            card.style.display = 'none';
                        }
                    });
                }

                btns.forEach(btn => {
                    btn.addEventListener('click', () => {
                        btns.forEach(b => b.classList.remove('active'));
                        btn.classList.add('active');
                        applyFilter(btn.dataset.category);
                    });
                });

                applyFilter("all");
            })();
        </script>




        <script>
            document.addEventListener("DOMContentLoaded", () => {

                let basket = JSON.parse(localStorage.getItem("basket")) || [];

                const toppingsData = {
                    "chicken-shawarma": ["🧄 Garlic", "🍅 Ketchup", "🌶 Chili Sauce"],
                    "pork-shawarma": ["🧄 Garlic", "🥓 BBQ Sauce", "🧅 Onions"],
                    "beef-burger": ["🧀 Cheese", "🥓 Bacon", "🥒 Pickles", "🍅 Ketchup"],
                    "chips": ["🧂 Salt", "🧀 Cheese Sauce", "🍛 Curry Sauce"]
                };

                document.querySelectorAll('.menu-card').forEach(card => {
                    const btn = card.querySelector('.add-btn');
                    btn.addEventListener('click', () => {
                        const itemKey = card.dataset.item || null;
                        const itemName = card.querySelector('h3').innerText;
                        const itemPrice = card.querySelector('.price').innerText;
                        const itemImage = card.querySelector('img').src;
                        const itemDesc = card.querySelector('.menu-card-description')?.innerText || "";

                        document.getElementById('modalItemName').innerText = itemName;
                        document.getElementById('modalItemPrice').innerText = itemPrice;
                        document.getElementById('modalItemImage').src = itemImage;
                        document.getElementById('modalItemDescription').innerText = itemDesc;

                        const form = document.getElementById('toppingsForm');
                        form.innerHTML = "";
                        if (itemKey && toppingsData[itemKey]) {
                            toppingsData[itemKey].forEach(topping => {
                                form.innerHTML += `
            <label class="topping-option">
              <input type="checkbox" value="${topping}">
              <span>${topping}</span>
            </label>
          `;
                            });
                        } else {
                            form.innerHTML = `<p class="no-toppings">No toppings available for this item.</p>`;
                        }

                        document.getElementById('toppingsModal').style.display = 'flex';
                    });
                });

                document.querySelector('.close-modal').addEventListener('click', () => {
                    document.getElementById('toppingsModal').style.display = 'none';
                });
                document.getElementById('cancelToppings').addEventListener('click', () => {
                    document.getElementById('toppingsModal').style.display = 'none';
                });

                document.getElementById("addToBasket").addEventListener("click", () => {
                    const selectedToppings = [...document.querySelectorAll('#toppingsForm input[type="checkbox"]:checked')]
                        .map(el => el.value);

                    const item = {
                        name: document.getElementById("modalItemName").innerText,
                        price: document.getElementById("modalItemPrice").innerText,
                        toppings: selectedToppings
                    };

                    basket.push(item);
                    localStorage.setItem("basket", JSON.stringify(basket));
                    updateBasketUI();

                    document.getElementById("toppingsModal").style.display = "none";
                });


                document.getElementById("basketBtn").addEventListener("click", (e) => {
                    e.preventDefault();
                    const dropdown = document.getElementById("basketDropdown");
                    dropdown.style.display = dropdown.style.display === "block" ? "none" : "block";
                });

                document.getElementById("basketItems").addEventListener("click", (e) => {
                    if (e.target.classList.contains("remove-btn")) {
                        const index = e.target.dataset.index;
                        basket.splice(index, 1);
                        localStorage.setItem("basket", JSON.stringify(basket));
                        updateBasketUI();
                    }
                });

                document.getElementById("clearBasketBtn").addEventListener("click", () => {
                    basket = [];
                    localStorage.setItem("basket", JSON.stringify(basket));
                    updateBasketUI();
                });

                document.getElementById("checkoutBtn").addEventListener("click", () => {
                    const isLoggedIn = document.body.dataset.loggedin === "true";

                    if (!isLoggedIn) {
                        alert("Please log in to continue with checkout.");
                        window.location.href = "login.php";
                        return;
                    }

                    document.getElementById("checkoutModal").style.display = "flex";
                });


                function updateBasketUI() {
                    document.getElementById("basketCount").innerText = basket.length;
                    const list = document.getElementById("basketItems");
                    list.innerHTML = "";

                    basket.forEach((item, index) => {
                        const li = document.createElement("li");
                        li.innerHTML = `
        <strong>${item.name}</strong>
        ${item.toppings && item.toppings.length > 0
                                ? `<small>Toppings: ${item.toppings.join(", ")}</small>`
                                : `<small>No toppings selected</small>`}
        <div class="item-footer">
          <span>${item.price}</span>
          <button class="remove-btn" data-index="${index}">Remove</button>
        </div>
      `;
                        list.appendChild(li);
                    });
                }

                updateBasketUI();
            });
        </script>

        <script>
            document.addEventListener("DOMContentLoaded", function () {
                document.getElementById("card-button").addEventListener("click", function () {
                    const formData = new FormData(document.getElementById("checkoutForm"));

                    const basket = JSON.parse(localStorage.getItem("basket")) || [];
                    formData.append("basket", JSON.stringify(basket));

                    fetch("php/process_payment.php", {
                        method: "POST",
                        body: formData
                    })
                        .then(res => res.json())
                        .then(data => {
                            if (data.success) {
                                alert("✅ Order placed successfully (fake payment).");
                                localStorage.removeItem("basket");
                                location.reload();
                            } else {
                                alert("❌ Failed: " + data.message);
                            }
                        });
                });
            });

        </script>

        <script>
            (function () {
                const hamburger = document.getElementById('hamburger');
                const navLinks = document.getElementById('nav-links');

                if (!hamburger || !navLinks) return;

                function toggleMenu() {
                    const open = navLinks.classList.toggle('active');
                    hamburger.setAttribute('aria-expanded', open ? 'true' : 'false');
                    hamburger.innerHTML = open
                        ? '<i class="fa-solid fa-xmark"></i>'
                        : '<i class="fa-solid fa-bars"></i>';
                }

                hamburger.addEventListener('click', toggleMenu);

                navLinks.addEventListener('click', (e) => {
                    if (e.target.tagName === 'A') {
                        navLinks.classList.remove('active');
                        hamburger.setAttribute('aria-expanded', 'false');
                        hamburger.innerHTML = '<i class="fa-solid fa-bars"></i>';
                    }
                });
            })();
        </script>


    </body>

</html>